#include <iostream>
using namespace std;

class Employee {
public:
    int empNumber;
    string name;
    double salary;
    Employee* left;
    Employee* right;

    Employee(int empNum, string empName, double empSalary) {
        empNumber = empNum;
        name = empName;
        salary = empSalary;
        left = right = nullptr;
    }
};

class EmployeeBST {
private:
    Employee* root;
    Employee* insert(Employee* node, int empNum, string empName, double empSalary) {
        if (node == nullptr) {
            return new Employee(empNum, empName, empSalary);
        }
        if (empNum < node->empNumber) {
            node->left = insert(node->left, empNum, empName, empSalary);
        } else if (empNum > node->empNumber) {
            node->right = insert(node->right, empNum, empName, empSalary);
        }
        return node;
    }
    Employee* search(Employee* node, int empNum) {
        if (node == nullptr || node->empNumber == empNum) {
            return node;
        }
        if (empNum < node->empNumber) {
            return search(node->left, empNum);
        }
        return search(node->right, empNum);
    }
    Employee* deleteEmployee(Employee* node, int empNum) {
        if (node == nullptr) return node;
        
        if (empNum < node->empNumber) {
            node->left = deleteEmployee(node->left, empNum);
        } else if (empNum > node->empNumber) {
            node->right = deleteEmployee(node->right, empNum);
        } else {
            if (node->left == nullptr) {
                Employee* temp = node->right;
                delete node;
                return temp;
            } else if (node->right == nullptr) {
                Employee* temp = node->left;
                delete node;
                return temp;
            }
            Employee* successorParent = node;
            Employee* successor = node->right;
            while (successor->left != nullptr) {
                successorParent = successor;
                successor = successor->left;
            }
            if (successorParent != node) {
                successorParent->left = successor->right;
                successor->right = node->right;
            }
            successor->left = node->left;

            delete node;
            return successor;
        }
        return node;
    }
    void inorder(Employee* node) {
        if (node != nullptr) {
            inorder(node->left);
            cout << "Emp No: " << node->empNumber << ", Name: " << node->name << ", Salary: " << node->salary << endl;
            inorder(node->right);
        }
    }
    void preorder(Employee* node) {
        if (node != nullptr) {
            cout << "Emp No: " << node->empNumber << ", Name: " << node->name << ", Salary: " << node->salary << endl;
            preorder(node->left);
            preorder(node->right);
        }
    }
    void postorder(Employee* node) {
        if (node != nullptr) {
            postorder(node->left);
            postorder(node->right);
            cout << "Emp No: " << node->empNumber << ", Name: " << node->name << ", Salary: " << node->salary << endl;
        }
    }

public:
    EmployeeBST() {
        root = nullptr;
    }

    void insert(int empNum, string empName, double empSalary) {
        root = insert(root, empNum, empName, empSalary);
    }
    void search(int empNum) {
        Employee* result = search(root, empNum);
        if (result != nullptr) {
            cout << "Employee Found - Emp No: " << result->empNumber << ", Name: " << result->name << ", Salary: " << result->salary << endl;
        } else {
            cout << "Employee with Emp No: " << empNum << " not found." << endl;
        }
    }
    void deleteEmployee(int empNum) {
        root = deleteEmployee(root, empNum);
    }
    void inorder() {
        cout << "In-order Traversal:" << endl;
        inorder(root);
        cout << endl;
    }
    void preorder() {
        cout << "Pre-order Traversal:" << endl;
        preorder(root);
        cout << endl;
    }
    void postorder() {
        cout << "Post-order Traversal:" << endl;
        postorder(root);
        cout << endl;
    }
};

int main() {
    EmployeeBST company;
    company.insert(1001, "Alice", 50000.0);
    company.insert(1002, "Bob", 55000.0);
    company.insert(1003, "Charlie", 60000.0);
    company.insert(1004, "Diana", 62000.0);
    company.insert(1005, "Edward", 48000.0);
    company.search(1003); 
    company.search(1010); 
    company.deleteEmployee(1002); 
    company.inorder();
    company.preorder();
    company.postorder();

    return 0;
}